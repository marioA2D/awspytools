# DynamoDB Datastore

This is a helper python package to assist in future projects

To build,

```bash
    python3 setup.py sdist bdist_wheel
```